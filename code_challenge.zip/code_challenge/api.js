//import fetch from "node-fetch";

const client = require("./index.js");
var uuid = require("uuid");
const getUuid = require("uuid-by-string");
const express = require("express");
const axios = require("axios");
var cors = require("cors");

const app = express();

app.listen(3300, () => {
  console.log("server is know listening");
});

app.use(
  cors({
    origin: "*",
  })
);

client.connect();
const bodyParser = require("body-parser");
app.use(bodyParser.json());
var jsonParser = bodyParser.json();

var urlencodedParser = bodyParser.urlencoded({ extended: false });
///////////select
app.get("/info", (req, res) => {
  client.query(`Select * from info`, (err, result) => {
    if (!err) {
      res.send(result.rows);
    }
  });

  client.end;
});

///////////////////////////////////insert
app.post("/info/:name/:address/:mobile", (req, res) => {
  const inf = req.params;

  console.log("HEre POST API CALL ----");

  const id = uuid.v1();
  let insertquery = `INSERT INTO info(id,address,mobile,name) VALUES('${id}','${inf.address}','${inf.mobile}','${inf.name}')`;

  client.query(insertquery, (err, result) => {
    if (!err) {
      res.send("inserration completed");

      //return result.rows;
    } else {
      console.log(err.message);
    }
  });

  client.end;
});
//////////////////////////////////////////update
app.put("/info/:id/:name/:address/:mobile", (req, res) => {
  let inf = req.params;

  var id1 = req.params.id;

  let updatequery = `UPDATE info
        set name='${inf.name}',
        address='${inf.address}',
        mobile='${inf.mobile}'
        where id= '${id1}'`;

  client.query(updatequery, (err, result) => {
    if (!err) {
      res.send("update completed");
    } else {
      console.log(err.message);
    }
  });

  client.end;
});
/////////////////////////////////////////delete
app.delete("/info/:id", (req, res) => {
  var id1 = req.params.id;

  let deletequery = `DELETE FROM info where id='${id1}'`;

  client.query(deletequery, (err, result) => {
    if (!err) {
      res.send("delete completed");

      //return result.rows;
    } else {
      console.log(err.message);
    }
  });

  client.end;
});
