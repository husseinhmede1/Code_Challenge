const { Client } = require("pg");

const client = new Client({
  user: "user",
  host: "localhost",
  database: "code_challenge",
  password: "root",
  port: 5432,
});

module.exports = client;
